KOSTSERVICE PRO 2.0 — FITUR PEMBAYARAN DAN NOTIFIKASI

INSTALASI XAMPP
1. Ekstrak folder KostService-Pro-v2 ke C:\xampp\htdocs\
2. Jalankan Apache dan MySQL.
3. Buka http://localhost/KostService-Pro-v2/install.php
4. Buat username/password admin.
5. Hapus install.php setelah instalasi.
6. Website: http://localhost/KostService-Pro-v2/
7. Admin: http://localhost/KostService-Pro-v2/admin/login.php

DATABASE
File db.sql berisi struktur database. install.php dapat membuat database dan tabel baru.
Untuk project KostService versi sebelumnya yang sudah memiliki tabel orders, jalankan:
http://localhost/KostService-Pro-v2/upgrade-v2.php
Hapus upgrade-v2.php setelah berhasil.

MIDTRANS
- Daftar Midtrans dan gunakan Sandbox terlebih dahulu.
- Isi MIDTRANS_SERVER_KEY dan MIDTRANS_CLIENT_KEY di config.php.
- Biarkan MIDTRANS_IS_PRODUCTION=false selama pengujian.
- Set Payment Notification URL pada dashboard Midtrans ke:
  https://DOMAIN-ANDA/midtrans-notification.php
- Webhook hanya dapat menjangkau server publik. Localhost perlu tunnel HTTPS.
- Status pembayaran final berasal dari webhook dengan signature valid, bukan dari redirect browser.
- Metode pembayaran yang muncul mengikuti pengaturan akun Midtrans.

WHATSAPP CLOUD API
- Buat aplikasi Meta for Developers dan aktifkan WhatsApp Cloud API.
- Ambil Phone Number ID dan System User Access Token dengan izin whatsapp_business_messaging.
- Isi WHATSAPP_GRAPH_VERSION, WHATSAPP_PHONE_NUMBER_ID, WHATSAPP_ACCESS_TOKEN.
- Ubah WHATSAPP_ENABLED=true.
- Tes dari admin > Uji WhatsApp.
- Pesan text bebas hanya untuk percakapan yang memenuhi ketentuan customer service window. Pesan bisnis di luar jendela tersebut memerlukan template yang disetujui Meta.
- Pelanggan harus setuju menerima notifikasi.

UPLOAD BUKTI
- Pelanggan dapat mengunggah JPG, PNG, PDF maksimal 3 MB.
- Server mengecek MIME menggunakan PHP fileinfo.
- File diberi nama acak dan disimpan di storage/payments.
- Admin login > Pesanan > Lihat bukti.
- Admin harus memeriksa mutasi rekening secara manual. Status belum otomatis menjadi Dibayar dari upload gambar.

KEAMANAN DAN BATASAN
- Simpan secret hanya di server; jangan kirim Server Key/token ke browser.
- Gunakan HTTPS, password kuat, backup rutin.
- Pastikan Apache menerapkan .htaccess pada folder storage; selain itu atur deny access pada konfigurasi server.
- Harga default di contoh adalah Rp25.000 per pesanan; sesuaikan setelah kesepakatan harga.
- Belum termasuk refund, rekonsiliasi otomatis, tombol persetujuan bukti manual, dan template WhatsApp.
- Uji di Sandbox sebelum transaksi sungguhan. Tinjau keamanan sebelum production.

DOKUMENTASI RESMI
Midtrans Snap: https://docs.midtrans.com/docs/snap-snap-integration-guide
Midtrans Webhook: https://docs.midtrans.com/docs/https-notification-webhooks
WhatsApp Cloud API: https://developers.facebook.com/docs/whatsapp/cloud-api/
