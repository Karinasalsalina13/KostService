<?php
require_once __DIR__.'/config.php';
function midtrans_create_snap(array $o,array $c):array{
 if(MIDTRANS_SERVER_KEY==='ISI_SERVER_KEY_MIDTRANS'||!MIDTRANS_SERVER_KEY)throw new RuntimeException('Isi Server Key Midtrans di config.php.');
 if(!function_exists('curl_init'))throw new RuntimeException('Aktifkan ekstensi cURL PHP.');
 $base=MIDTRANS_IS_PRODUCTION?'https://app.midtrans.com':'https://app.sandbox.midtrans.com';
 $data=['transaction_details'=>['order_id'=>$o['order_code'],'gross_amount'=>(int)$o['total_amount']],
 'customer_details'=>['first_name'=>$c['name'],'phone'=>preg_replace('/\D+/','',$c['phone'])],
 'item_details'=>[['id'=>$o['service'],'price'=>(int)$o['total_amount'],'quantity'=>1,'name'=>$o['service']]]];
 $ch=curl_init($base.'/snap/v1/transactions');curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_USERPWD=>MIDTRANS_SERVER_KEY.':',CURLOPT_POSTFIELDS=>json_encode($data),CURLOPT_TIMEOUT=>25]);
 $body=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);
 if($body===false)throw new RuntimeException('Koneksi Midtrans gagal: '.$err);$r=json_decode($body,true);
 if($code<200||$code>=300||empty($r['token'])||empty($r['redirect_url']))throw new RuntimeException('Midtrans: '.($r['error_messages'][0]??'Respons tidak valid.'));
 return $r;
}
function whatsapp_send(string $phone,string $message):bool{
 if(!WHATSAPP_ENABLED||WHATSAPP_ACCESS_TOKEN==='ISI_PERMANENT_ACCESS_TOKEN'||WHATSAPP_PHONE_NUMBER_ID==='ISI_PHONE_NUMBER_ID'||!function_exists('curl_init'))return false;
 $to=preg_replace('/\D+/','',$phone);if(str_starts_with($to,'0'))$to='62'.substr($to,1);
 $url='https://graph.facebook.com/'.WHATSAPP_GRAPH_VERSION.'/'.WHATSAPP_PHONE_NUMBER_ID.'/messages';
 $payload=['messaging_product'=>'whatsapp','recipient_type'=>'individual','to'=>$to,'type'=>'text','text'=>['preview_url'=>false,'body'=>$message]];
 $ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.WHATSAPP_ACCESS_TOKEN,'Content-Type: application/json'],CURLOPT_POSTFIELDS=>json_encode($payload,JSON_UNESCAPED_UNICODE),CURLOPT_TIMEOUT=>20]);
 $res=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);return $res!==false&&$status>=200&&$status<300;
}
function notify_customer(string $phone,string $msg):void{try{whatsapp_send($phone,$msg);}catch(Throwable $e){error_log($e->getMessage());}}
