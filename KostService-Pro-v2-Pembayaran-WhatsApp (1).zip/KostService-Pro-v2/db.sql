CREATE DATABASE IF NOT EXISTS kostservice CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE kostservice;
CREATE TABLE IF NOT EXISTS admins(id INT AUTO_INCREMENT PRIMARY KEY,username VARCHAR(60) NOT NULL UNIQUE,password_hash VARCHAR(255) NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS customers(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,phone VARCHAR(20) NOT NULL UNIQUE,address VARCHAR(255) NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS orders(
 id INT AUTO_INCREMENT PRIMARY KEY,order_code VARCHAR(30) NOT NULL UNIQUE,customer_id INT NOT NULL,
 service VARCHAR(60) NOT NULL,service_date DATE NOT NULL,details TEXT NULL,
 status ENUM('Menunggu Konfirmasi','Dikonfirmasi','Sedang Dikerjakan','Selesai','Dibatalkan') NOT NULL DEFAULT 'Menunggu Konfirmasi',
 total_amount INT UNSIGNED NOT NULL DEFAULT 25000,
 payment_status ENUM('Belum Dibayar','Menunggu Pembayaran','Dibayar','Gagal','Dikembalikan') NOT NULL DEFAULT 'Belum Dibayar',
 payment_method VARCHAR(40) NULL,midtrans_token VARCHAR(255) NULL,midtrans_redirect_url TEXT NULL,payment_reference VARCHAR(120) NULL,
 proof_file VARCHAR(255) NULL,proof_status ENUM('Belum Ada','Menunggu Verifikasi','Disetujui','Ditolak') NOT NULL DEFAULT 'Belum Ada',
 paid_at DATETIME NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_customer FOREIGN KEY(customer_id) REFERENCES customers(id)
);
CREATE TABLE IF NOT EXISTS payment_logs(id BIGINT AUTO_INCREMENT PRIMARY KEY,order_code VARCHAR(30) NOT NULL,provider VARCHAR(30) NOT NULL,event_type VARCHAR(80) NOT NULL,payload_json LONGTEXT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(order_code));
