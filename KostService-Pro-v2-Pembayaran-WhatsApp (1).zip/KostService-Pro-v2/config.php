<?php
session_start();
define('DB_HOST','localhost'); define('DB_NAME','kostservice'); define('DB_USER','root'); define('DB_PASS','');
define('MIDTRANS_SERVER_KEY','ISI_SERVER_KEY_MIDTRANS');
define('MIDTRANS_CLIENT_KEY','ISI_CLIENT_KEY_MIDTRANS');
define('MIDTRANS_IS_PRODUCTION',false);
define('WHATSAPP_GRAPH_VERSION','v23.0');
define('WHATSAPP_PHONE_NUMBER_ID','ISI_PHONE_NUMBER_ID');
define('WHATSAPP_ACCESS_TOKEN','ISI_PERMANENT_ACCESS_TOKEN');
define('WHATSAPP_ENABLED',false);
function db(): PDO { static $p=null; if(!$p){$p=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);} return $p; }
function e($v): string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function csrf_token(): string{if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32));return $_SESSION['csrf'];}
function verify_csrf(): void{if($_SERVER['REQUEST_METHOD']==='POST'&&!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')){http_response_code(419);exit('Token formulir tidak valid. Muat ulang halaman.');}}
function admin_required():void{if(empty($_SESSION['admin_id'])){header('Location: login.php');exit;}}
function rupiah($n):string{return 'Rp'.number_format((float)$n,0,',','.');}
